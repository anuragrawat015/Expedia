import { HttpClient ,HttpHeaders} from "@angular/common/http";
import { Injectable } from "@angular/core";
import {of} from 'rxjs';
import { Wrap } from "../wrap";

@Injectable({
    providedIn:'root'
})
export class MasterService{
    apiurl="https://autosuggest-orxe-service.qa.cnxloyalty.com/api/autosuggest/v1.0/search"
   
       
        sessionID="862e8666-aff9-42ef-b94a-a57851e02ae9";
        token= "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjbngtdGVuYW50SWQiOiIzZTFnbzRpbHhxOCIsImNueC1zZXNzaW9uaWQiOiI4NjJlODY2Ni1hZmY5LTQyZWYtYjk0YS1hNTc4NTFlMDJhZTkiLCJjbngtY29ycmVsYXRpb25JZCI6ImFmYWYxYzY3LWNlMDItNTllOC0zN2IxLTVjZGIzMGM0ZThkNiIsIkNTUkYtVG9rZW4iOiJhZTY2NmViYi0wOWU1LTQ2YTEtYmNmMy1jMmUxZjA3ZDJmNjQiLCJjbGllbnQtaWQiOiIxMDMiLCJwcm9ncmFtLWlkIjoiMTM4OSIsInByb2dyYW0tZ3JvdXAtaWQiOiI1MDgiLCJkZXZpY2UtdHlwZSI6Ik1vYmlsZSIsInBhcnRpY2lwYW50LWNvZGUiOiI1MzA2NTk5IiwibmJmIjoxNjYyMDkwNjUxLCJleHAiOjE2NjIwOTQyNTEsImlhdCI6MTY2MjA5MDY1MSwiaXNzIjoiaHR0cHM6Ly9vcnhlLWFwaS5xYS5jbnhsb3lhbHR5LmNvbSJ9.HWCFJUG7Zi1jhJqESDUs7EReTakS2SlcSK7o3TpQ9VI";               
      clientID= "3e1go4ilxq8";
    
    constructor(private http:HttpClient)
    {


      

    }
    

    hello(data:any)
    {
        var header = {

            'content-type': 'application/json',
    
            "Authorization": 'Bearer ' + this.token,
    
            'cnx-sessionId': this.sessionID,
    
            'cnx-tenantId': this.clientID,
    
          }
        return this.http.post<Wrap>(this.apiurl,data,{'headers':header});
    }
}