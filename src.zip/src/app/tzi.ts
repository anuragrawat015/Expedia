
export interface Tzi {

    tz: string,

     dt: Date

}