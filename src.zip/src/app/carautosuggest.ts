
import { Tzi } from "./tzi";



export interface Carautosuggest {

    c: string,

    cc: string,

    cd: string,

    cn: string,

    d: string,

    iaa: boolean,

    lId: string,

    lat: number,

    lng: number,

    n: string,

    nbcn:string,

    sc: string,

    sl: object[],

    t: string,

    tzi: Tzi

}