
import { Carautosuggest } from "./carautosuggest";



export interface Wrap {

    s:Carautosuggest[]

}