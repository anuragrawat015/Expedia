import { Component ,OnInit } from '@angular/core';
import  {HttpClient} from '@angular/common/http';
import { MasterService } from './service/master.service';
import { Carautosuggest } from './carautosuggest';
// import { Injectable } from  '@angular/core';
// @Injectable({
//   providedIn:  'root'
//   })
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Expedia';
  
  data : Carautosuggest[]|undefined;
  constructor(private service: MasterService)
  {

  }
  getVal(val:any)
  {
      
      console.warn(val.target.value)
  }
  getAns(event:any)
  {
    if(event.target.value!="")
    {
      let data={
        "sq": {
          "st": event.target.value,
          "sf": [
            "airport",
            "city"
          ]
        },
        "sel": true,
        "rec": 20,
        "c": "cars"
      }
      this.service.hello(data).subscribe(result=>{
        this.data = result.s;
        console.log(result);
      });
    }
    
 
      
  }

}
